## Made my Jack's Development

Simple teleporter script

-- command --
/goto (id)

If you need any help dm my discord at crazymf#5286 on discord