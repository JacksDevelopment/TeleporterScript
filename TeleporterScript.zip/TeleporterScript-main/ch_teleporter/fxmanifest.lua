fx_version 'cerulean'
game       'gta5'


server_scripts {
    'server.lua',
}



client_scripts {
    'client.lua'
}